-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2021 at 04:06 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fwms`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_active` int(11) NOT NULL DEFAULT '0',
  `brand_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `brand_active`, `brand_status`) VALUES
(6, 'Cheese', 1, 2),
(8, 'Alaska', 1, 1),
(9, 'Eden', 2, 1),
(10, 'Argentina', 2, 1),
(11, 'UFC', 1, 1),
(12, 'Joly', 1, 1),
(13, 'Mang Tomas', 2, 1),
(14, 'Datu Puti', 1, 2),
(15, 'Lucky Me', 2, 1),
(16, 'Magi', 1, 1),
(17, 'Silver Swan', 2, 1),
(18, 'Silver Swan', 1, 1),
(19, 'Fiesta', 1, 1),
(20, 'Mega', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `categories_name` varchar(255) NOT NULL,
  `categories_active` int(11) NOT NULL DEFAULT '0',
  `categories_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `categories_name`, `categories_active`, `categories_status`) VALUES
(10, 'Can Goods', 1, 1),
(11, 'Bottled Stocks', 1, 1),
(12, 'Food Pack', 1, 1),
(13, 'Noodles', 1, 1),
(14, 'Pasta', 1, 1),
(15, 'Chocolate Bars', 2, 1),
(16, 'Powder', 2, 1),
(17, 'Raw Meat', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `expiry`
--

CREATE TABLE `expiry` (
  `expiry_id` int(255) NOT NULL,
  `productid` varchar(255) NOT NULL,
  `Expiration_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` text NOT NULL,
  `brand_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_image`, `brand_id`, `categories_id`, `quantity`, `rate`, `active`, `status`) VALUES
(15, 'Alaska Evaporated Milk', '../assests/images/stock/105256765560f8ff9857bcc.png', 8, 10, '43', '40', 1, 1),
(16, 'Lucky Me Chicken', '../assests/images/stock/2533173560f6ef919e6ac.jpg', 12, 13, '100', '10', 2, 1),
(17, 'Corned Beef', '../assests/images/stock/113128075260f6efe22061f.jpg', 10, 10, '199', '25', 1, 1),
(18, 'Cheese', '../assests/images/stock/170353831960f6effc01cf2.jpg', 9, 12, '26', '20', 1, 1),
(19, 'Toyo', '../assests/images/stock/65414433060f8db10c341c.jpg', 14, 14, '2', '20', 2, 1),
(20, 'Fiesta Spaghetti', '../assests/images/stock/161991922460f92b43d2678.png', 19, 13, '15', '99', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `ingredients_id` int(255) NOT NULL,
  `recipe_id` int(255) NOT NULL,
  `ingredients_amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recipe_suggestion`
--

CREATE TABLE `recipe_suggestion` (
  `recipe_id` int(255) NOT NULL,
  `recipe_name` varchar(255) NOT NULL,
  `description` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recycling_suggestion`
--

CREATE TABLE `recycling_suggestion` (
  `recy_Id` int(255) NOT NULL,
  `expiry_Id` int(255) NOT NULL,
  `fwd_id` int(255) NOT NULL,
  `Recipe_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `request_id` int(11) NOT NULL,
  `request_date` date NOT NULL,
  `Staff_name` varchar(255) NOT NULL,
  `Staff_pos` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`request_id`, `request_date`, `Staff_name`, `Staff_pos`, `user_id`, `order_status`) VALUES
(8, '2021-07-20', 'Dave Visto', 'Crew', 11, 0);

-- --------------------------------------------------------

--
-- Table structure for table `request_item`
--

CREATE TABLE `request_item` (
  `request_item_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `request_item_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request_item`
--

INSERT INTO `request_item` (`request_item_id`, `request_id`, `product_id`, `quantity`, `rate`, `total`, `request_item_status`) VALUES
(1, 1, 1, '1', '2000', '2000.00', 2),
(2, 1, 1, '1', '2000', '2000.00', 2),
(3, 1, 1, '1', '2000', '2000.00', 2),
(4, 1, 1, '1', '2000', '2000.00', 2),
(5, 0, 1, '1', '2000', '2000.00', 1),
(6, 2, 1, '1', '2000', '2000.00', 2),
(7, 3, 2, '1', '700', '700.00', 2),
(8, 3, 3, '1', '800', '800.00', 2),
(9, 4, 6, '1', '900', '900.00', 2),
(10, 4, 9, '1', '4300', '4300.00', 2),
(11, 5, 2, '1', '700', '700.00', 2),
(14, 6, 4, '3', '30', '30.00', 1),
(15, 6, 2, '1', '700', '700.00', 1),
(16, 7, 14, '1', '2000', '2000.00', 1),
(17, 7, 14, '1', '2000', '2000.00', 1),
(18, 8, 15, '1', '40', '40.00', 1),
(19, 8, 17, '1', '25', '25.00', 1),
(20, 8, 18, '1', '20', '20.00', 1),
(21, 0, 15, '1', '40', '40.00', 1),
(22, 0, 15, '1', '40', '40.00', 1),
(23, 0, 18, '1', '20', '20.00', 1),
(24, 0, 15, '1', '40', '40.00', 1),
(25, 0, 15, '1', '40', '40.00', 1),
(26, 0, 18, '1', '20', '20.00', 1),
(27, 0, 15, '1', '40', '40.00', 1),
(28, 0, 15, '1', '40', '40.00', 1),
(29, 0, 18, '1', '20', '20.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', ''),
(11, 'dave', '1610838743cc90e3e4fdda748282d9b8', 'davevisto08@gmail.com'),
(13, 'staff', '1253208465b1efa876f982d8a9e73eef', 'newstaff@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `expiry`
--
ALTER TABLE `expiry`
  ADD PRIMARY KEY (`expiry_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`ingredients_id`);

--
-- Indexes for table `recipe_suggestion`
--
ALTER TABLE `recipe_suggestion`
  ADD PRIMARY KEY (`recipe_id`);

--
-- Indexes for table `recycling_suggestion`
--
ALTER TABLE `recycling_suggestion`
  ADD PRIMARY KEY (`recy_Id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `request_item`
--
ALTER TABLE `request_item`
  ADD PRIMARY KEY (`request_item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `expiry`
--
ALTER TABLE `expiry`
  MODIFY `expiry_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  MODIFY `ingredients_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recipe_suggestion`
--
ALTER TABLE `recipe_suggestion`
  MODIFY `recipe_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recycling_suggestion`
--
ALTER TABLE `recycling_suggestion`
  MODIFY `recy_Id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `request_item`
--
ALTER TABLE `request_item`
  MODIFY `request_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
