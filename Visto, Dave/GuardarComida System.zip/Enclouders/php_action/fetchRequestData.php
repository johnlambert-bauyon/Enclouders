<?php 	

require_once 'core.php';

$requestId = $_POST['requestId'];

$valid = array('order' => array(), 'order_item' => array());

$sql = "SELECT request.request_id, request.request_date, request.staff_name, request.staff_pos,  FROM request 	
	WHERE request.request_id = {$requestId}";

$result = $connect->query($sql);
$data = $result->fetch_row();
$valid['request'] = $data;


$connect->close();

echo json_encode($valid);